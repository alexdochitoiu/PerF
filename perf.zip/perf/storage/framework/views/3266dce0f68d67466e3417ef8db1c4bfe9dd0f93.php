<?php $__env->startSection('title'); ?>
    Perf

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('bootstrap_css'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/index.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('jquery'); ?>
    <script
            src="https://code.jquery.com/jquery-3.2.1.js"
            integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
            crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('text-header'); ?>
   <p class="bine_ai_venit">Bine ai venit pe</p>
    <p class="header_perf_text"> PerF</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>