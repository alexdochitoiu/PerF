<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('bootstrap_css'); ?>



</head>
<body >

<div class="header">
<div class="container color-container-header container-min container-custom">
    <div class="row">
        <div class="col-sm-4 col-xs-6">
            <img class="logo" src="images/logo.png" alt="ímagine_logo"/>
        </div>
        <div class="col-sm-8 col-xs-6">
            <p class="in-block padding-top-right-20">Inregistrare</p>
            <p class="in-block padding-top-right-20">Autentificare</p>
        </div>
        <div class="text-header col-sm-12 col-xs-12">
        <?php echo $__env->yieldContent('text-header'); ?>
        </div>
        <div class="col-sm-6 col-xs-10">
            <div class="col-sm-6 col-xs-6">
                <div class="dropdown padding-left-15">
                    <button class="btn btn-default dropdown-toggle dropdown-button margin-8-0 width-80" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Dropdown
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-xs-6">
                <div class="dropdown padding-left-15">
                    <button class="btn btn-default dropdown-toggle dropdown-button margin-8-0 width-80" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Dropdown
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xs-6">
                <form class="navbar-form" role="search">
                    <div class="input-group add-on width-80">
                        <input class="form-control" placeholder="Search" name="srch-term" id="srch-term" type="text">
                        <div class="input-group-btn">
                            <button class="btn btn-default search" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                        </div>
                    </div>
                </form>

    </div>
</div>
</div>
<?php echo $__env->yieldContent('jquery'); ?>
</body>
</html>
